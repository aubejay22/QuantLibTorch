from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

root = Path.cwd()
out = root / 'docs/benchmarks'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def git(*args):
    return subprocess.check_output(['git', *args], text=True).strip()
def flatten(x):
    if isinstance(x, list):
        return [a for v in x for a in flatten(v)]
    return [x]

manifest = dict(created_at_utc=datetime.now(timezone.utc).isoformat(),
                baseline_git=git('rev-parse', '4e90e37'), implementation_git=git('rev-parse', '2cd9e5f'),
                quantlib_pin=git('-C', 'third_party/QuantLib', 'rev-parse', 'HEAD'))
assert not git('-C', 'third_party/QuantLib', 'status', '--porcelain')
old_cpp = git('ls-tree', '-r', '--name-only', '4e90e37', '--', 'cpp').splitlines()
assert git('diff', '4e90e37', '--name-status', '--', 'cpp') == 'A\tcpp/coefficient_pde.cpp'
assert not git('diff', '4e90e37', '--', 'cmake/quantlib_sources.cmake')
manifest['unchanged_prior_cpp_files'] = old_cpp
manifest['unchanged_quantlib_translation_unit_manifest'] = True

verification = []
for name in ['neural_sde_phase21.json', 'neural_sde_phase21_pilot.json']:
    # Store portable LF evidence without changing any measured JSON values.
    path = out/name
    path.write_text(path.read_text(encoding='utf-8'), encoding='utf-8', newline='\n')
    report = json.loads((out / name).read_text())
    records = report['results']
    cases = [r for r in records if r.get('case', {}).get('kind') == 'timing']
    price_errors, gradient_errors, counts = [], [], 0
    for f in cases:
        c = f['case']
        if c['mode'] != 'full':
            continue
        a = next(r for r in cases if r['case']['mode'] == 'adjoint'
                 and all(r['case'][k] == c[k] for k in ['nx', 'ny', 'steps', 'latent_dimensions']))
        price_errors.append(abs(f['price']-a['price']))
        fg, ag = flatten(f['gradients']), flatten(a['gradients'])
        assert len(fg) == len(ag)
        gradient_errors.extend(abs(x-y) for x, y in zip(fg, ag))
        counts += len(fg)
    assert max(price_errors) < 1e-11 and max(gradient_errors) < 1e-9
    for r in records:
        if 'final_loss' in r:
            assert r['final_loss'] < r['loss_history'][0]/10
    verification.append(dict(report=name, prices=len(price_errors), gradients=counts,
        max_price_difference=max(price_errors), max_gradient_difference=max(gradient_errors)))
    # Pilot's changed measurement driver is preserved exactly in its archive.
    with zipfile.ZipFile(out / 'neural_sde_phase21_pilot_source.zip') as pilot:
        for path, expected in report['source_sha256'].items():
            raw = pilot.read(path) if name.endswith('pilot.json') and path in pilot.namelist() else (root/path).read_bytes()
            assert sha(raw) == expected, path
manifest['cross_mode_validation'] = verification

logs = {'build/phase21_build.log': 'neural_sde_phase21_build.txt',
        'build/phase21_full_tests.log': 'neural_sde_phase21_tests.txt',
        'build/phase21_pde_tests.log': 'neural_sde_phase21_pde_tests.txt',
        'build/phase21_financial_tests.log': 'neural_sde_phase21_financial_initial_tests.txt',
        'build/phase21_evidence_selected.log': 'neural_sde_phase21_commands.txt'}
for source, dest in logs.items():
    raw = (root/source).read_bytes()
    text = raw.decode('utf-16' if raw.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig')
    text = '\n'.join(line.rstrip() for line in text.splitlines())+'\n'
    (out/dest).write_text(text, encoding='utf-8', newline='\n')
assert '1742 passed' in (out/'neural_sde_phase21_tests.txt').read_text()

overlay = root/'build/native/quantlib-overlay'
check = root/'build/phase21_overlay_check'
subprocess.run([sys.executable, 'scripts/prepare_quantlib.py', 'third_party/QuantLib', str(check)], check=True)
overlay_files = sorted(p.relative_to(overlay) for p in overlay.rglob('*') if p.is_file())
assert overlay_files == sorted(p.relative_to(check) for p in check.rglob('*') if p.is_file())
for path in overlay_files:
    assert (overlay/path).read_bytes() == (check/path).read_bytes(), path
manifest['regenerated_overlay_files'] = len(overlay_files)

names = git('ls-files').splitlines()
sources = [n for n in names if n.startswith(('cpp/', 'python/', 'tests/', 'scripts/', 'examples/', 'cmake/', 'LICENSES/'))
           and Path(n).suffix in ('.cpp', '.hpp', '.py', '.cmake', '.txt', '.md')]
sources += ['CMakeLists.txt', 'pyproject.toml', 'PROJECT_CONTEXT.md', 'README.md', 'docs/architecture.md']
manifest['source_sha256'] = {p: sha((root/p).read_bytes()) for p in sorted(sources)}
archive_path = out/'neural_sde_phase21_source.zip'
with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(sources):
        archive.write(root/p, p)
    for p in overlay_files:
        archive.write(overlay/p, 'quantlib-overlay/'+p.as_posix())
    archive.write(__file__, 'preserve_evidence.py')
with zipfile.ZipFile(archive_path) as archive:
    for p, expected in manifest['source_sha256'].items():
        assert sha(archive.read(p)) == expected
manifest['archive_sha256'] = sha(archive_path.read_bytes())
manifest['artifact_sha256'] = {p.name: sha(p.read_bytes()) for p in out.glob('neural_sde_phase21*')
                              if p.name != 'neural_sde_phase21_preservation.json'}
binary = root/'python/quantlibtorch/_native/quantlibtorch_native.dll'
manifest['binary_sha256'] = sha(binary.read_bytes())
assert manifest['binary_sha256'] == json.loads((out/'neural_sde_phase21.json').read_text())['binary_sha256']
(out/'neural_sde_phase21_preservation.json').write_text(json.dumps(manifest, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(dict(sources=len(sources), old_cpp=len(old_cpp), overlays=len(overlay_files),
                     comparisons=verification, archive_sha256=manifest['archive_sha256']), indent=2))
