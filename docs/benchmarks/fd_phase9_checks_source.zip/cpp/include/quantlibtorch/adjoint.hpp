#pragma once

#include <ql/math/array.hpp>

namespace QuantLib { class TripleBandLinearOp; }

namespace quantlibtorch {

// The mode belongs to one synchronous pricing call, never to a process-wide
// flag. Nested solves restore the previous mode, including on exceptions.
bool adjoint_enabled();
bool operator_adjoint_enabled();
class AdjointMode {
  public:
    explicit AdjointMode(bool enabled);
    ~AdjointMode();
    AdjointMode(const AdjointMode&) = delete;
    AdjointMode& operator=(const AdjointMode&) = delete;
  private:
    bool previous_;
};

QuantLib::Array adjoint_split(const QuantLib::TripleBandLinearOp& op,
    const QuantLib::Array& rhs, QuantLib::Real a, QuantLib::Real b,
    const QuantLib::Real* lower, const QuantLib::Real* diagonal,
    const QuantLib::Real* upper);

QuantLib::Array adjoint_tridiagonal(const QuantLib::Array& lower, const QuantLib::Array& diagonal,
    const QuantLib::Array& upper, const QuantLib::Array& rhs);

QuantLib::Array adjoint_apply(const QuantLib::TripleBandLinearOp& op, const QuantLib::Array& rhs,
    const QuantLib::Real* lower, const QuantLib::Real* diagonal, const QuantLib::Real* upper,
    const QuantLib::Size* left, const QuantLib::Size* right);

bool try_diffusion_assembly(QuantLib::TripleBandLinearOp& output,
    const QuantLib::TripleBandLinearOp& dx, const QuantLib::TripleBandLinearOp& dxx,
    const QuantLib::Array& variance, QuantLib::Real rate, QuantLib::Real yield);

} // namespace quantlibtorch
