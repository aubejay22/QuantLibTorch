"""Explicit, worker-local runtime controls for reproducible benchmarks only."""
import ctypes
import sys


def windows_process_qos(disable=False):
    if sys.platform != 'win32':
        if disable:
            raise RuntimeError('Process power-throttling control requires Windows')
        return None
    from ctypes import wintypes
    # https://learn.microsoft.com/windows/win32/api/processthreadsapi/nf-processthreadsapi-setprocessinformation
    # SDK 10.0.26100.0: ProcessPowerThrottling=4, version=1, EXECUTION_SPEED=0x1.
    class Policy(ctypes.Structure):
        _fields_ = [(name, wintypes.ULONG) for name in ('version', 'control_mask', 'state_mask')]
    kernel = ctypes.WinDLL('kernel32', use_last_error=True)
    kernel.GetCurrentProcess.restype = wintypes.HANDLE
    signature = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
    kernel.GetProcessInformation.argtypes = signature
    kernel.GetProcessInformation.restype = wintypes.BOOL
    kernel.SetProcessInformation.argtypes = signature
    kernel.SetProcessInformation.restype = wintypes.BOOL
    policy = Policy(1, 0, 0)
    process = kernel.GetCurrentProcess()
    if not kernel.GetProcessInformation(process, 4, ctypes.byref(policy), ctypes.sizeof(policy)):
        raise ctypes.WinError(ctypes.get_last_error())
    if disable:
        policy.control_mask |= 1
        policy.state_mask &= ~1
        if not kernel.SetProcessInformation(process, 4, ctypes.byref(policy), ctypes.sizeof(policy)):
            raise ctypes.WinError(ctypes.get_last_error())
        return windows_process_qos()
    return dict((name, getattr(policy, name)) for name, _ in Policy._fields_)


def worker_qos(choice):
    if choice not in ('system', 'high'):
        raise ValueError('unknown worker QoS policy')
    before = windows_process_qos()
    if choice == 'high':
        windows_process_qos(disable=True)
    return dict(requested=choice, before=before, after=windows_process_qos())
