"""Two differentiation strategies sharing QuantLib's native Thomas solver."""
from pathlib import Path
import sys

import torch
from torch.autograd.function import once_differentiable


def _load_native() -> None:
    suffix = ".dll" if sys.platform == "win32" else ".dylib" if sys.platform == "darwin" else ".so"
    library = Path(__file__).parent / "_native" / ("quantlibtorch_native" + suffix)
    if not library.exists():
        raise ImportError("QuantLibTorch native library missing. Run python scripts/build.py; see README.md")
    torch.ops.load_library(str(library))


_load_native()


class _DiscreteAdjoint(torch.autograd.Function):
    @staticmethod
    def forward(ctx, lower, diagonal, upper, rhs):
        # Function.forward runs without autograd recording. Both strategies use
        # the same compiled QuantLib implementation, including its pivot checks.
        x = torch.ops.quantlibtorch.solve(lower, diagonal, upper, rhs)
        ctx.save_for_backward(lower, diagonal, upper, x)
        return x

    @staticmethod
    @once_differentiable
    def backward(ctx, grad_output):
        lower, diagonal, upper, x = ctx.saved_tensors
        lam = torch.ops.quantlibtorch.solve(upper, diagonal, lower, grad_output)
        return -lam[1:] * x[:-1], -lam * x, -lam[:-1] * x[1:], lam


def tridiagonal_solve(lower, diagonal, upper, rhs, *, mode="full"):
    """Solve A x = rhs for a CPU float64 tridiagonal matrix, n >= 2.

    Diagonal lengths are (n-1, n, n-1); rhs is length n. Inputs may be
    noncontiguous. The no-pivot QuantLib solver requires nonzero elimination
    pivots, so invertibility alone is insufficient; diagonally dominant PDE
    matrices are the intended use. No batching or automatic dtype conversion.

    ``full`` records ATen operations inside the upstream algorithm.
    ``adjoint`` records a custom first-order VJP using A.T lambda = grad_output,
    without recording elimination. Higher derivatives require ``full``.
    """
    if mode == "full":
        return torch.ops.quantlibtorch.solve(lower, diagonal, upper, rhs)
    if mode == "adjoint":
        return _DiscreteAdjoint.apply(lower, diagonal, upper, rhs)
    raise ValueError("mode must be 'full' or 'adjoint'")
