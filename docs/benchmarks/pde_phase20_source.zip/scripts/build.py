"""Configure and build the native library against this Python's installed torch."""
import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-dir", type=Path, default=ROOT / "build" / "native")
    parser.add_argument("--boost-include", type=Path)
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--no-math-patch", action="store_true", help="Reproduce the expected upstream compilation failure")
    args = parser.parse_args()
    if args.jobs < 1:
        parser.error("--jobs must be positive")
    # Validate provenance without fetching or modifying existing sources.
    subprocess.run([sys.executable, str(ROOT / "scripts" / "bootstrap.py")], check=True)
    command = ["cmake", "-S", str(ROOT), "-B", str(args.build_dir),
               f"-DPython3_EXECUTABLE={sys.executable}",
               f"-DQLT_COMPILE_JOBS={args.jobs}",
               f"-DQLT_PATCH_MATH={'OFF' if args.no_math_patch else 'ON'}"]
    if sys.platform == "win32":
        command += ["-G", "Visual Studio 17 2022", "-A", "x64"]
    else:
        command += ["-DCMAKE_BUILD_TYPE=Release"]
    if args.boost_include:
        command += [f"-DQLT_BOOST_INCLUDE_DIR={args.boost_include.resolve()}"]
    subprocess.run(command, check=True)
    subprocess.run(["cmake", "--build", str(args.build_dir), "--config", "Release",
                    "--parallel", str(args.jobs)], check=True)


if __name__ == "__main__":
    main()
