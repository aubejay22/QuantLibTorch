# QuantLibTorch

Packed neural SDE calibration is available through `LatentBatch` and
`LatentCalibration(..., execution="batched")`. It shares coefficient assembly
and directional solves across compatible common-expiry contracts, while keeping
QuantLib's spatial stencils, ADI formulas, time scheduler, payoff averaging and
financial spline interpolation. Both full AD and first-order equation adjoints
are supported. The original serial APIs remain available.

```python
from quantlibtorch import LatentBatch

plan = LatentBatch([85., 100., 115.], axes=axes, times=times,
                   time_steps=24, scheme="hundsdorfer")
prices = plan.price(latent_drift, diffusion, initial_state, mode="adjoint")
loss = ((prices - targets) / scales).square().mean()
loss.backward()
```

Only European calls/puts with shared numerical configuration can use a plan.
Incompatible meshes, schemes, curves or expiries are rejected by
`LatentBatch.from_contracts`; exercise schedules, cash dividends, damping and
custom boundary conditions are not supported by batching. The existing
single-contract engines retain their exercise and dividend capabilities.
Plans cache only fixed data, and can be reused with fresh neural fields.

CPU float64 is the primary implementation. `device="cuda"` opts into an
experimental device-resident coefficient/rollback path with PCR admissibility
and residual checks. Its financial readout uses connected CPU transfers.
See the [Phase 23 record](docs/architecture.md#phase-23-packed-coefficients-and-compatible-contract-calibration)
for measured performance, memory, price/sensitivity refinement and restrictions.
To run the Phase 22 fit through batching, append `--execution batched` to the
calibration example command below.

The complete build passes **1,865 tests**. In the selected nine-contract
81 x 17 adjoint workload, serial/packed CPU totals are **57.67 / 0.457 s**,
including cleanup, and peak process growth is **685 / 191 MiB**. Both AD modes
reproduce the Phase 22 fit in about eight seconds. GPU execution wins only on
the largest tested grid; mesh refinement still moves some prices more than the
calibration residual. The architecture report includes sensitivity convergence
and all timing, memory and accuracy qualifications.

Multi-contract neural SDE calibration now uses the existing QuantLib latent
pricing engine through `OptionQuote` and `LatentCalibration`. Neural drift and
diffusion parameters and a bounded latent initial state can be optimized
jointly. `loss()` retains a price-vector graph; `backward()` accumulates the
same separable objective one contract at a time to limit peak memory. Both
full AD and discrete adjoints remain available.

The Phase 22 benchmark fits nine independent analytic-Heston quotes over
three strikes and three maturities, checks six unseen contracts, and separates
spatial, temporal, domain, financial, gradient and performance diagnostics.
It uses synthetic quotes and CPU float64. See the
[calibration findings and next milestone](docs/architecture.md#phase-22-multi-contract-neural-sde-calibration-readiness)
for measured accuracy, runtime, memory, and limitations. Phase 21 checkpoints
`2cd9e5f` and `3e66775` are preserved.

After the setup below, reproduce the selected joint fit with:

```text
.venv/Scripts/python.exe examples/calibrate_neural_sde.py docs/benchmarks/calibration_phase22_market.json --mesh space --mode adjoint --iterations 15 --output build/calibration.json
```

Here `space` selects the recorded 81 x 17 calibration grid. The example takes
several minutes on CPU; `--mesh diagnostic --iterations 3` is a quick API
demonstration with insufficient resolution for financial accuracy claims.
The training example fits one latent factor; two-factor workloads are measured
separately on diagnostic grids.
The complete benchmark commands and raw measurements are linked in the
architecture record.

The new joint-state APIs support neural SDE coefficient fields while retaining
QuantLib's spatial operators, ADI rollback, payoff averaging and exercise:

- `state_grid(axes)` gives fixed mesh coordinates `[nodes, directions]`.
- `diffusion_rollback` accepts time-dependent drift and diffusion loadings in
  any spatial dimension; tests cover one through four dimensions.
- `fd_latent` prices equity options with one or two latent factors using the
  existing QuantLib 2D/3D solvers. Covariance is `L @ L.T`, stock drift is fixed
  by risk-neutral curves, and initial log-spot/latent states are differentiable.

Both full AD and first-order discrete adjoints are supported. These APIs use
fixed meshes, CPU float64 tensors and explicit field shapes; see their
[contracts and validation](docs/architecture.md#phase-21-joint-state-neural-diffusions-and-latent-state-pricing).
Run a small end-to-end training example with:

```text
.venv/Scripts/python.exe examples/neural_latent_sde.py --mode adjoint
.venv/Scripts/python.exe examples/neural_latent_sde.py --mode full --latent-dimensions 2
```

An experimental **Approach A** integration of QuantLib's actual
`FdBlackScholesVanillaEngine` and `Fd2dBlackScholesVanillaEngine` with PyTorch.
The engines and their dependency closure
are compiled with `QL_REAL = TorchReal`; no stock QuantLib library is linked.
Python local-volatility tensors retain their autograd connection through the
QuantLib instrument, operator assembly, rollback, exercise, and interpolation.

The [architectural review](docs/architecture.md#architectural-review-general-differentiable-pde-solvers-2026-11-01)
assesses the Phase 19 discrete adjoints, scheme coverage, and the path to general
PDE coefficient inverse problems. The user approved the next multidimensional
integration milestone; existing performance work is preserved in Git baseline
`5b0de25`.

Two differentiation modes share the forward pricing engines:

- `full`: AD through the selected numerical operations, including higher derivatives.
- `adjoint`: first-order custom VJPs for supported time steps, operator assembly,
  application, and solves, using native implementations of pinned QuantLib
  arithmetic and transpose solves. Events and interpolation remain connected
  to autograd.

The CPU path retains tensor backing across arrays, reuses graph-connected spatial
samples and immutable passive spatial bases within each price, and vectorizes
array arithmetic and spline expressions.
The default `kernels="auto"` uses fused CPU Thomas arithmetic in full AD for
well-scaled, strictly diagonally dominant systems with an acceptable residual.
Its reverse recurrence preserves graph-connected higher derivatives. Forward
duals and unsupported native cases retain tensor parallel cyclic reduction
(PCR); systems outside the guarded domain use QuantLib's original solver.
`kernels="vectorized"` keeps the upstream TorchReal Thomas path for all full-AD
solves. Adjoint mode uses native CPU step/solve arithmetic inside its explicit
VJP boundaries, retaining original routines as fallbacks. Supported full-mode
steps pass the original assembled band tensor into one elementary preparation
operation, reuse the Douglas application, and preserve the guarded solve and
its elimination-state graph. The operator clears that tensor before every
assembly and keeps original Array coefficients available for fallback paths.
Supported first-order steps also consume the original matrix and return one
matrix gradient, removing redundant row-selection edges while retaining their
explicit first-order contract.
Financial objects,
mesh, discretization, exercise/dividend order,
and spline definitions are preserved. See the
[current performance investigation](docs/architecture.md) for exact contracts,
provenance, measurements, and reproducible ablations.

With matched Windows HighQoS benchmark workers, Phase 11 reduces 30-step/61-point
surface adjoint price/VJP time from **23.8 to 12.0 ms (1.98×)** and neural
pricing-loss time from **24.3 to 12.7 ms (1.91×)** against Phase 10. Surface
inference improves from **15.8 to 6.7 ms (2.35×)**. Native assembly and step
arithmetic preserve the original expression ordering and pivot rules inside
the first-order boundaries. Full-mode controls retain their previous times
and graph-connected higher derivatives. The Phase 22 build passed **1,756 tests**,
including **30 mixed-AD checks** for forward tangents supplied through VJP
weights, **23 basis-cache checks**, **78 full tensor-step checks**, and **74
time-variance checks**, **101 step-preparation checks**, and **93 assembled-band
checks**, **91 adjoint-band checks**, and **101 requested-gradient checks**,
plus **168 multidimensional/structured-operator/basket checks** and **102 general
diffusion/latent-state checks**, and **14 multi-contract calibration checks**.
The preserved Phase 19 build also passed **319 checks with requested-gradient
selection disabled** and 203 checks with original assembly forward arithmetic selected.
Earlier full-mode and adjoint fallback results remain archived.
Tests include independent
prices/VJPs, events, higher derivatives, forward AD, function transforms,
tracing, and batched CPU/CUDA solves. Benchmark drivers expose
`--windows-qos high` and optional `--affinity` controls because diagnostics
show large timing changes with execution-speed policy and logical processor
placement; the library leaves those settings to its caller. Historical results
and source snapshots are preserved in the
[architecture record](docs/architecture.md). These numerical-kernel CUDA tests
do not establish GPU option-pricing throughput.

Phase 19 evaluates only requested full-mode assembly VJPs while preserving
original inputs and higher/mixed derivatives. At 30/61 it removes 660
gradient-construction tensor calls and 132 temporary/repeated saves, with
unchanged retained graphs. The pilot improves default-Thomas HVP totals;
the selected repeat has mixed timings, including regressions. Ordinary
first-order paths are unchanged. See the
[Phase 19 record](docs/architecture.md#phase-19-requested-full-mode-assembly-gradients)
for complete measurements, validation, and preserved source snapshots.

Phase 18 passes the original assembly matrix into first-order steps. In the
selected CPU-8 HighQoS repeat, neural pricing loss improves from **7.44 to
6.08 ms (1.22x)** and 60/121 surface pricing from **12.69 to 11.59 ms (1.09x)**.
All **1,504** matched price/VJP samples are identical. At 30/61, graph size falls
from **387 to 288** nodes and backward tensor calls from **2,624 to 1,700**.
The 120/241 total is unchanged in this repeat, and inference gains are mixed
across runs. Full-mode higher derivatives remain unchanged. See the
[Phase 18 record](docs/architecture.md#phase-18-original-bands-in-first-order-steps)
for the pilot, controls, validation, limitations, and source snapshots.

Phase 17 passes the original assembly matrix directly into full-mode step
preparation, retaining its complete derivative graph. Selected 30/61 neural
pricing loss improves from **8.63 to 7.35 ms (1.17x)**, and 120/241 surface
pricing from **31.12 to 28.62 ms (1.09x)** against Phase 16. All 940 matched
price/VJP samples are identical. The same CPU-8 HighQoS repeat measures
**10.04 to 7.35 ms** and **40.70 to 28.62 ms** against Phase 15. Ratios vary
by workload and run; unchanged adjoint/inference controls expose residual host
timing variation. See the
[Phase 17 record](docs/architecture.md#phase-17-retain-original-assembled-bands)
for validation, the revised prototype, and source archives.

Phase 16 combines full-mode step preparation while preserving higher and
mixed derivatives. With HighQoS workers pinned to logical CPU 8, 30/61 neural
pricing loss improves from **9.53 to 7.21 ms (1.32x)**, and 60/121 surface
pricing from **17.76 to 13.67 ms (1.30x)**. The unrestricted pilot also improves;
an intermediate repeat has scheduling-related timing changes on unchanged
paths. Default-Thomas Hessian-vector workloads improve, while PCR results vary.
See the [Phase 16 record](docs/architecture.md#phase-16-elementary-step-preparation)
for the retained samples, runtime controls, validation, and source archives.

Phase 15 evaluates time interpolation and squaring inside one elementary
autograd operation, retaining original coefficient rows and higher derivatives.
Selected 60/121 surface adjoint pricing improves from **21.95 to 19.49 ms
(1.13x)**, and 120/241 from **45.20 to 42.30 ms (1.07x)**. All 1,598 selected
matched price/VJP samples are identical. Full-mode results are mixed, while
inference and curvature timings show no consistent gain. See the
[Phase 15 record](docs/architecture.md#phase-15-elementary-time-variance-arithmetic)
for reversed-order measurements, controls, and source archives.

Phase 14 composes supported full-mode steps directly from the existing
differentiable kernels. Matched 120/241 surface pricing improves from
**83.57 to 65.36 ms (1.28x)** and 30/61 neural pricing loss from
**18.99 to 16.15 ms (1.18x)**. Complete 30/61 surface/neural Hessian-vector
workloads improve from **72.79/72.98 to 64.93/65.45 ms** with the default
solver. See the [Phase 14 record](docs/architecture.md#phase-14-full-mode-tensor-steps)
for measured scope, variable PCR controls, verification, and source archives.

Phase 13 reuses immutable passive spatial bases within each price. Matched
120-step/241-point surface adjoints improve from **51.28 to 47.25 ms**, and
inference from **35.78 to 30.00 ms**. Gains vary by workload: the selected
30/61 neural full-mode repeat is slightly slower (**18.87 to 19.13 ms**).
Prices and VJPs are identical in all 1,410 selected cache-on/off samples.
See the [Phase 13 record](docs/architecture.md#phase-13-reuse-of-immutable-spatial-bases)
for the complete comparisons, diagnostic limitation, and source archives.

The new `fd_vanilla` API uses QuantLib's `VanillaOption`, yield/dividend curves,
Black–Scholes process and automatic mesher, payoff averaging, stopping times,
cash-dividend jumps, European/American/Bermudan exercise, and cubic interpolation.
Its tensor-backed local-volatility term structure is the main custom adapter.
The original Python PDE example and tridiagonal API remain available.

## Two-asset local-volatility basket pricing

`fd_basket` uses QuantLib's 2D mesh, mixed-derivative operator, directional
solves, ADI rollback, exercise and bicubic interpolation. Both local-volatility
surfaces and correlation are differentiable. The structured directional adjoint
solves transpose equations and returns compact coefficient VJPs; it does not
record elimination or construct solution Jacobians.

```python
import torch
from quantlibtorch import fd_basket

sigma1 = torch.tensor(0.22, dtype=torch.float64, requires_grad=True)
sigma2 = torch.tensor(0.28, dtype=torch.float64, requires_grad=True)
rho = torch.tensor(0.35, dtype=torch.float64, requires_grad=True)
price = fd_basket(
    sigma1, sigma2, rho,
    basket="min", option_type="call",
    scheme="hundsdorfer", mode="adjoint",
    time_steps=6, grid_points=(15, 11),
)
vol1_vjp, vol2_vjp, correlation_vjp = torch.autograd.grad(
    price, (sigma1, sigma2, rho)
)
```

Douglas, Craig-Sneyd, modified Craig-Sneyd and Hundsdorfer are available with
full AD or first-order equation adjoints. Min/max basket calls/puts,
European/American/Bermudan exercise, a shared discount curve and separate
dividend-yield curves retain QuantLib's behavior. Each volatility can instead
be a sampled time/log-spot tensor produced by a neural network; use `times1`,
`log_spots1`, `times2` and `log_spots2` to supply its fixed coordinates.

Independent `mesh_volatility1` and `mesh_volatility2` settings fix the
automatic mesh for coefficient sensitivities. The coarse example grid is
illustrative; assess mesh/domain convergence for the application. Pricing
is CPU float64 and unbatched. Damping must be zero, since multidimensional
implicit-Euler/Krylov adjoints are not implemented. Custom boundaries and
cash dividends are not exposed by this basket adapter. Exercise and
interpolation derivatives follow their executed branches.

The [Phase 20 record](docs/architecture.md#phase-20-structured-adjoints-and-a-real-multidimensional-quantlib-engine)
documents the contracts, independent dense/manufactured/stock QuantLib
references, performance, memory, and remaining limitations.
The complete suite passes 1,640 tests. Measured 15 × 11 neural basket-loss
execution is 958 ms with full AD and 366 ms with adjoints; at 31 × 21 it is
6.43 s and 2.25 s. These CPU measurements include cleanup and do not establish
batched or GPU throughput. Preserved 1D controls have identical matched
prices/VJPs and retain their prior performance range.

## Build from source

Requirements: Git, Python 3.10+, PyTorch, CMake 3.24+, a C++17 compiler compatible
with that PyTorch build, and Boost headers. Verified locally with Windows 11,
Python 3.13.5, PyTorch 2.10.0+cu126, MSVC 19.44, CMake 3.29.2, and Boost 1.82.
The original financial engines are CPU-only; `LatentBatch` additionally exposes
the targeted CUDA prototype described above. Tensor kernels dispatch to CUDA
through PyTorch; a CUDA toolkit is unnecessary for this extension build.
Windows requires Visual Studio 2022 C++ Build Tools.

With PyTorch and pytest already installed, create an isolated environment that
can reuse them. In PowerShell:

```powershell
python -m venv --system-site-packages .venv
.venv/Scripts/python.exe scripts/bootstrap.py
.venv/Scripts/python.exe scripts/build.py
.venv/Scripts/python.exe -m pip install --no-build-isolation --no-deps -e .
.venv/Scripts/python.exe -m pip install QuantLib==1.40
.venv/Scripts/python.exe -m pytest -q
.venv/Scripts/python.exe examples/neural_fd_engine.py --mode full
.venv/Scripts/python.exe examples/neural_fd_engine.py --mode adjoint
.venv/Scripts/python.exe examples/neural_local_vol.py --mode full
.venv/Scripts/python.exe examples/neural_local_vol.py --mode adjoint
```

For a fresh environment, install PyTorch and pytest first (CPU packages suffice).
For Linux, install compiler/CMake/Git/Boost headers, use `.venv/bin/python`, and
run the same Python scripts. A Linux CPU CI workflow is included; its remote run
has not been verified in the local Windows session.

`bootstrap.py` downloads QuantLib **v1.40**, verifies commit
`06edddbdb85f006c43a449b5fc846a00c67477f3`, and refuses an unexpected or modified
checkout. It is a deliberate reproducible baseline, not a claim to use the
latest QuantLib release. Subsequent builds work offline. Dependencies live in
ignored `third_party/`; build output lives in `build/` and
`python/quantlibtorch/_native/`.

Boost is detected in standard include paths or the Python/Conda installation.
If necessary, pass `--boost-include PATH` to `scripts/build.py`, where `PATH`
contains `boost/version.hpp`. Use MSVC on Windows, not MinGW with an MSVC
PyTorch wheel. Build against the same Python/PyTorch used at runtime; rebuild
after changing PyTorch. The package pins the tested PyTorch 2.10.0 baseline;
Debug LibTorch configurations are not supported. The QuantLib Python wheel is
only an independent test dependency, invoked in a separate process. The
extension builds all required QuantLib code from the pinned source checkout.

**Installation is source/editable-only for this milestone.** The Python
packaging step does not compile C++; run the build script first. Native wheel
building/distribution and `pip install .` as a complete installation workflow
are not supported yet.

## Use

```python
import torch
from quantlibtorch import fd_vanilla

sigma = torch.tensor(0.2, dtype=torch.float64, requires_grad=True)
price = fd_vanilla(sigma, mode="adjoint")
vega, = torch.autograd.grad(price, sigma)
print(price.item(), vega.item())
```

For neural coefficients, supply a CPU float64 tensor of shape
`(len(times), len(log_spots))` and fixed Python coordinate sequences. `times`
uses Actual/365 Fixed years since valuation; `log_spots` uses `log(S)`, not
log-moneyness. The adapter interpolates bilinearly in time/log-spot and holds
edge values constant outside the sample domain. Singleton axes are constant.
See [the engine neural example](examples/neural_fd_engine.py).

```python
from datetime import date

price = fd_vanilla(
    sigma,
    option_type="put", exercise="bermudan",
    valuation_date=date(2025, 1, 1), maturity_date=date(2026, 1, 1),
    exercise_dates=[date(2025, 7, 1), date(2026, 1, 1)],
    cash_dividends=[(date(2025, 4, 1), 1.5)],
    discount_curve=[(date(2025, 1, 1), 1.), (date(2026, 1, 1), .97)],
    mode="adjoint",
)
```

Optional `discount_curve` and `dividend_curve` contain dated discount factors
and use QuantLib log-linear interpolation. Otherwise `rate` and
`dividend_yield` define flat continuously compounded curves. Dates, financial
inputs, axes, and grid choices are fixed; only local-volatility samples receive
gradients. Cash dividends use QuantLib's spot model. American exercise starts
at valuation. The day counter is Actual/365 Fixed and dates are unadjusted.
Other conventions, escrowed dividends, quanto adjustments, and other instrument
types are not exposed in this slice.

`mesh_volatility` (default .2) controls the upstream automatic mesh, independently
of the differentiable surface. Keep it fixed when checking coefficient VJPs.
Mesh/domain and time-step convergence must be checked for each model. Available
schemes are `douglas`, `crank_nicolson`, and `implicit_euler`, with upstream
damping-step behavior. Prices and derivatives can be sensitive to exercise and
spline-limiter branch changes.

The legacy `european_call` still accepts `(time_steps, interior_nodes)` samples
on `log_moneyness_grid`; it retains its custom Python assembly and boundaries.
See [the original neural example](examples/neural_local_vol.py).

The lower-level `tridiagonal_solve(lower, diagonal, upper, rhs, mode=...)`
accepts one-dimensional CPU float64 tensors with lengths `(n-1, n, n-1, n)`,
`n >= 2`. It supports noncontiguous views and differentiates every diagonal
and RHS. It uses a no-pivot solver: nonzero elimination pivots are required;
general matrix invertibility is insufficient.

## Verification and measured scope

```powershell
.venv/Scripts/python.exe -m pytest -q
ctest --test-dir build/native -C Release --output-on-failure
.venv/Scripts/python.exe scripts/benchmark.py --repeats 7 --output build/benchmark.json
.venv/Scripts/python.exe scripts/benchmark_fd.py --repeats 5 --output build/fd_benchmark.json
.venv/Scripts/python.exe scripts/investigate_fd.py --grids 30x61 --output build/fd_investigation.json
```

Tests cover dense-reference solutions and VJPs, finite-difference `gradcheck`,
full-mode second derivatives, explicit adjoint double-backward rejection,
input validation, Black–Scholes price/vega convergence, and neural-parameter
directional derivatives. Adjoint mode currently supports first derivatives
only. Engine tests additionally compare with a stock QuantLib 1.40 process,
including dated curves, exercise, dividends, and fixed-mesh volatility bumps.
The original `fd_vanilla` API does not expose `torch.compile`, batching or GPU
pricing. `LatentBatch` supplies the separate multi-contract path described above.
Standalone application/assembly/PCR kernels below support CPU/CUDA batches.

The legacy prototype rejects nonmonotone centered stencils. The new engine
preserves QuantLib's own spatial/boundary behavior, including its limitations;
it does not apply that legacy stencil rule. The scalar tensor adapter remains
expensive. Per-solve adjoints reduce elimination graphs, but memory still grows
with the trajectory. GPU execution for this legacy path and trajectory
checkpointing remain future work.

See [architecture and verified findings](docs/architecture.md) for the exact
compatibility patch, results, limitations, and next steps;
[raw CPU measurements](docs/benchmarks/cpu_initial.json) retain their environment.
The engine benchmark also records an isolated stock QuantLib baseline; see
[engine CPU measurements](docs/benchmarks/fd_engine_cpu.json).

The Phase 3 Windows build passes **128 tests**, including the original prototype.
C++ constants now use native double arithmetic until mixed with tensors, and
the volatility adapter reuses graph-connected coefficient views. Tensor inputs
retain their graphs, and the actual QuantLib engine and numerical algorithms
remain in use.

At 30 time steps / 61 points, measured forward/backward/cleanup totals improve
by **1.49× (full)** and **1.62× (adjoint)** for constant volatility, and **1.31× /
1.39×** for a nonuniform surface. Constant-surface adjoint peak working-set
growth falls by about **36%**. Performance remains far from stock QuantLib:
graph-disabled inference is still about 514× slower, and differentiated forward
execution about 5,000× slower on that constant-volatility workload.

The investigation script isolates timing, process memory, graph census, and
operator profiling in separate processes. It retains raw warmups and samples;
cold/warm timing variability is substantial on this host. See the
[Phase 3 findings](docs/architecture.md#phase-3-cpu-performance-investigation)
and [ablation measurements](docs/benchmarks/fd_phase3_ablation.json) for controls,
limitations, reproduction commands, and the next optimization boundaries.

## Batched tensor kernels (Phase 4)

The Windows build passes **179 tests**, including batched dense-reference VJPs,
finite differences, reflected boundaries, event cases, and a CUDA/CPU reference
check. On the measured 30/61 European workloads, vector hooks improve total
price/gradient time by **1.39–1.52×** over the Phase 3 scalar path; the tested
Bermudan/dividend workload improves by **1.58×**.

`fd_vanilla(..., kernels="vectorized")` uses whole-vector coefficient sampling,
array arithmetic, spline expressions, band application, row scaling, and band
assembly inside QuantLib. The current `auto` default additionally selects guarded
native CPU Thomas arithmetic for suitable full-AD systems, with tensor PCR for
unsupported native cases. `kernels="scalar"` selects the original upstream path;
`kernels="apply"` vectorizes application alone for measurement. The upstream
mesh, time stepping, solve algorithm, exercise/dividend events, and interpolation
remain in use. The pricing API still takes one contract on CPU.

The same package provides batched numerical primitives with explicit node and
right-hand-side axes:

```python
from quantlibtorch import tridiagonal_apply, band_axpyb
import torch

# B independent operators, N nodes, R right-hand sides per operator.
B, N, R = 32, 121, 4
diagonal = torch.full((B, N), 2., dtype=torch.float64, requires_grad=True)
off = torch.full((N-1,), -.1, dtype=torch.float64)  # shared across the batch
rhs = torch.ones(B, N, R, dtype=torch.float64)
values = tridiagonal_apply(off, diagonal, off, rhs)
gradient, = torch.autograd.grad(values.square().mean(), diagonal)
```

Bands have shapes `(..., N-1)`, `(..., N)`, `(..., N-1)` and values have shape
`(..., N, R)`. Leading dimensions broadcast, including shared coefficients;
use `R=1` explicitly for one RHS. `band_axpyb(a, x, y, b)` assembles
`y + a*x + diag(b)` from row-packed `(..., 3, N)` bands and `(..., N)` or
`(..., 1)` scales. Only the central diagonal receives b. Both primitives
support noncontiguous dense float64 tensors, first/higher derivatives, and
CPU or CUDA when all inputs share a device. They do not mutate inputs or scan
values for finiteness; nonfinite inputs propagate as in PyTorch arithmetic.

These application/assembly kernels are not a GPU pricing engine. The standalone
`tridiagonal_solve_pcr` described below adds a batched numerical solve.
The extension still links only LibTorch CPU/platform libraries; ATen
dispatches whole tensor operations to CUDA supplied by the installed PyTorch
wheel. CUDA kernels do not pass through the CPU-only TorchReal scalar adapter.

```powershell
.venv/Scripts/python.exe scripts/investigate_fd.py --grids 30x61 --variants optimized --kernels scalar,apply,vectorized --tasks timing --warmup 3 --repeats 5 --output build/fd_kernels.json
.venv/Scripts/python.exe scripts/benchmark_tensor_kernels.py --devices cpu,cuda --output build/tensor_kernels.json
```

See the [Phase 4 milestone and results](docs/architecture.md#phase-4-batched-tensor-kernels)
for validation, conversion costs, throughput measurements, and the path to
batched option prices and gradients on GPU.

The latest CPU optimization switches are diagnostic process settings, read by
the native library. `scripts/benchmark_fd_optimizations.py` sets them in fresh
workers and compares baseline, native solve, tensor backing, vector sampling,
array arithmetic, lazy scalar views, spline expressions, PCR stages, and fused
Thomas arithmetic. The current selected level is `phase19`; `phase18` disables
selection of requested assembly gradients in full-mode higher backward;
`phase17` also disables
the adjoint assembled-band handoff, `phase16` also disables
the full-mode handoff, `phase15` disables
elementary step preparation, `phase14` disables
elementary time-variance arithmetic, `phase13` disables
full-mode tensor-step composition, `phase11` disables
immutable basis reuse, and `phase10` retains
the previous first-order boundaries, while `phase9` retains
the preceding guarded PCR selection. `QLT_THOMAS_ARITHMETIC=0` restores that
selection, while `QLT_THOMAS_VECTOR_BACKWARD=0` selects the slower serial
higher-derivative fallback. `QLT_ADJOINT_ARITHMETIC_FORWARD=0` restores original
assembly/application forwards inside first-order boundaries, and
`QLT_STEP_NATIVE_ARITHMETIC=0` restores original step forward/backward execution.
`QLT_BASIS_CACHE=0` restores packing of spatial derivative operators on each
assembly. `QLT_FULL_TENSOR_STEP=0` restores the preceding full-mode step.
`QLT_TIME_VARIANCE_ARITHMETIC=0` restores the original tensor expression for
time interpolation and squaring. `QLT_STEP_PREPARATION=0` restores the preceding
band/RHS preparation expressions. `QLT_ASSEMBLED_BANDS=0` restores separate
band-row inputs to that preparation. `QLT_ADJOINT_ASSEMBLED_BANDS=0` restores
separate band-row inputs to first-order steps and inference.
`QLT_DIFFUSION_SELECTED_GRADS=0` evaluates all assembly input gradients during
full-mode graph-building backward. All eleven switches default to one.
Every price/gradient timing includes
construction, forward, backward and graph cleanup. `--surfaces neural` also
includes coefficient-network evaluation and a squared pricing-loss VJP.

```powershell
.venv/Scripts/python.exe scripts/benchmark_fd_optimizations.py --levels baseline,final --grids 30x61 --variants optimized --kernels vectorized --surfaces constant,surface,neural --modes inference,full,adjoint --tasks timing --warmup 3 --repeats 5 --output build/fd_optimizations.json
.venv/Scripts/python.exe scripts/benchmark_fd_optimizations.py --levels final,current --kernel-overrides final=vectorized,current=auto --grids 30x61 --variants optimized --surfaces surface,neural --modes full,adjoint --tasks timing --warmup 8 --repeats 9 --no-stock --output build/fd_phase6.json
.venv/Scripts/python.exe scripts/benchmark_fd_optimizations.py --levels phase9,phase10 --grids 30x61 --variants optimized --kernels auto --surfaces surface,neural --modes full --tasks timing --warmup 32 --repeats 15 --windows-qos high --no-stock --output build/fd_phase10.json
.venv/Scripts/python.exe scripts/benchmark_fd_curvature.py --strategies pcr,vector --grids 10x31,30x61 --surfaces surface,neural --warmup 32 --repeats 15 --windows-qos high --output build/fd_phase10_curvature.json
.venv/Scripts/python.exe scripts/benchmark_fd_optimizations.py --levels phase10,phase11 --grids 30x61 --variants optimized --kernels auto --surfaces surface,neural --modes adjoint,inference --tasks timing --warmup 32 --repeats 15 --windows-qos high --no-stock --output build/fd_phase11.json
.venv/Scripts/python.exe scripts/benchmark_fd_optimizations.py --levels phase11,phase13 --grids 30x61 --variants optimized --kernels auto --surfaces surface,neural --modes full,adjoint,inference --tasks timing --warmup 32 --repeats 15 --windows-qos high --no-stock --output build/fd_phase13.json
.venv/Scripts/python.exe scripts/benchmark_fd_optimizations.py --levels phase13,phase14 --grids 30x61,120x241 --variants optimized --kernels auto --surfaces surface --modes full --tasks timing --warmup 32 --repeats 15 --windows-qos high --no-stock --output build/fd_phase14.json
.venv/Scripts/python.exe scripts/benchmark_fd_optimizations.py --levels phase14,phase15 --grids 30x61,120x241 --variants optimized --kernels auto --surfaces surface --modes full,adjoint,inference --tasks timing --warmup 32 --repeats 15 --windows-qos high --no-stock --output build/fd_phase15.json
.venv/Scripts/python.exe scripts/benchmark_fd_optimizations.py --levels phase15,phase16 --grids 30x61,60x121 --variants optimized --kernels auto --surfaces surface,neural --modes full --tasks timing --warmup 32 --repeats 15 --windows-qos high --affinity 8 --no-stock --output build/fd_phase16.json
.venv/Scripts/python.exe scripts/benchmark_fd_optimizations.py --levels phase16,phase17 --grids 30x61,120x241 --variants optimized --kernels auto --surfaces surface,neural --modes full --tasks timing --warmup 32 --repeats 15 --windows-qos high --affinity 8 --no-stock --output build/fd_phase17.json
.venv/Scripts/python.exe scripts/benchmark_fd_optimizations.py --levels phase17,phase18 --grids 30x61,60x121 --variants optimized --kernels auto --surfaces surface,neural --modes adjoint,inference --tasks timing --warmup 32 --repeats 15 --windows-qos high --affinity 8 --no-stock --output build/fd_phase18.json
.venv/Scripts/python.exe scripts/benchmark_fd_curvature.py --grids 30x61 --surfaces surface,neural --strategies vector,pcr --basis-cache 1 --full-tensor-step 1 --time-variance-arithmetic 1 --step-preparation 1 --assembled-bands 1 --adjoint-assembled-bands 1 --diffusion-selected-grads 1 --profile --warmup 32 --repeats 15 --windows-qos high --affinity 8 --output build/fd_phase19_curvature.json
```

Choose a valid logical processor for `--affinity`, or omit it to allow normal
scheduling. Affinity reduces placement variation but does not fix CPU frequency
or competing load; inspect raw samples and unchanged controls.
Repeat the curvature command with `--diffusion-selected-grads 0` to compare
the preceding assembly backward. Optional profiling runs after timed samples.

## Parallel tridiagonal solve

`tridiagonal_solve_pcr` supports the same band/batch/RHS shapes as
`tridiagonal_apply`, including shared matrices, noncontiguous tensors, full
reverse AD, higher derivatives, and forward AD on CPU/CUDA:

```python
from quantlibtorch import tridiagonal_solve_pcr

solution = tridiagonal_solve_pcr(off, diagonal, off, rhs)
gradient, = torch.autograd.grad(solution.square().mean(), diagonal)
```

This experimental primitive uses parallel cyclic reduction, with different
floating-point ordering and pivot requirements from Thomas elimination. It is
intended initially for well-scaled, diagonally dominant systems. By default,
it rejects nonfinite inputs/output and zero/nonfinite pivots at every stage;
on CUDA, those checks synchronize the device. `check_pivots=False` avoids host
reads but makes the caller responsible for admissibility and residual checks.
Inputs are never mutated. This primitive does not assemble a financial engine.

CPU PCR stages fuse forward elimination and its ordinary backward. Higher
derivatives, forward duals, function transforms, and fake-tensor tracing preserve
their graph connections; unsupported native cases retain the tensor recurrence.
For one RHS, fusion is limited to 32,768 broadcast rows and does not expand
shared matrix bands into extra RHS batches. These choices avoid measured CPU
regressions. `QLT_PCR_NATIVE_STAGE=0` disables stage fusion. The separate
`addcmul` experiment remains disabled by default (`QLT_PCR_FUSED=0`).

Native CPU solver-selection predicates and full-AD assembly/application are
enabled by default. Set `QLT_NATIVE_SOLVE_CHECKS=0`,
`QLT_ASSEMBLY_ARITHMETIC=0`, or `QLT_OPERATOR_ARITHMETIC=0` to restore their
tensor paths. `QLT_ARITHMETIC_NATIVE_FORWARD=0` retains the elementary VJPs but
uses the original QuantLib forward routines inside those boundaries. The direct
forward preserves upstream expression ordering and actual neighbor indices;
only fresh buffers are written, and saved original coefficients retain higher
derivatives. Unsupported wrappers/transforms use functional tensor arithmetic.

For CPU pricing, prefer the guarded `kernels="auto"` default, which falls back
to QuantLib's original solver outside its conservative domain. Explicit
`kernels="pcr", mode="full"` selects checked PCR splitting and can reject
matrices accepted by Thomas. Use `kernels="vectorized"` to retain Thomas
throughout full AD. The same mesh, time steps, exercise/dividend events, and
pricing equations apply; derivatives remain piecewise at exercise and spline
limiter branches.

```powershell
.venv/Scripts/python.exe scripts/benchmark_parallel_solve.py --devices cpu,cuda --output build/pcr_throughput.json
.venv/Scripts/python.exe scripts/benchmark_fd_optimizations.py --levels phase9,phase8,phase7 --grids 30x61 --variants optimized --kernels auto --surfaces surface,neural --modes full --tasks timing --warmup 32 --repeats 15 --windows-qos high --output build/phase9_pricing.json
```

This benchmark separates resident-device timings from input/output/gradient
transfer costs and validates each device against CPU dense solutions/VJPs in
separate workers. It does not measure GPU option pricing.
