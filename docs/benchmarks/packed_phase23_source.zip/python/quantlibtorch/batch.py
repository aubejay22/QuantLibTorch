"""Shared-operator contract plans using packed QuantLib coefficient/stage kernels."""
from __future__ import annotations

from datetime import date
import math

import torch

from .fd import _curve, _integer, _serial
from .latent import _axes, _config, _fields, _tensor
from .pricing import _finite_number


class LatentBatch:
    """A reusable fixed plan for common-expiry European calls and puts.

    All contracts share exactly one mesh, coefficient-time grid, maturity,
    curves, scheme, step count, initial state and model fields. Only strikes
    and option types vary. No mesh merging, time rescaling, event alignment or
    boundary substitution is performed. Cash dividends, exercise schedules,
    damping and custom boundary conditions are explicitly rejected.

    The plan owns passive QuantLib derivative bases, indices, averaged payoffs
    and financial configuration only. Every price call creates a fresh model
    graph. Arrays passed to the constructor are copied. Full AD retains higher
    derivatives; equation adjoints are first order. Both use the original ADI
    formulas and scheduler. Float64; no torch.func/compile contract.

    device='cuda' is an experimental device-resident coefficient/rollback
    path using tensor PCR, with strict row diagonal dominance and scaled solve
    residual checks. CPU uses checked Thomas arithmetic. CUDA financial spline
    readout runs on CPU through connected transfers; device synchronization and
    these transfers can outweigh GPU gains. No GPU speedup is implied.
    """
    def __init__(self, strikes, *, axes, times=(0.,), option_types=None,
                 valuation_date=date(2025, 1, 1), maturity_date=date(2026, 1, 1),
                 rate=.03, dividend_yield=.01, discount_curve=None, dividend_curve=None,
                 time_steps=30, scheme="hundsdorfer", exercise="european",
                 exercise_dates=(), cash_dividends=(), boundary_conditions=(),
                 damping_steps=0, device="cpu"):
        axes = _axes(axes, minimum=4)
        if len(axes) not in (2, 3):
            raise ValueError("LatentBatch supports one or two latent states")
        if exercise != "european" or exercise_dates:
            raise ValueError("LatentBatch requires European exercise without exercise dates")
        if cash_dividends:
            raise ValueError("LatentBatch does not support cash dividends")
        if boundary_conditions:
            raise ValueError("LatentBatch does not support custom boundary conditions")
        if _integer("damping_steps", damping_steps, 0) != 0:
            raise ValueError("LatentBatch requires zero damping_steps")
        reference, maturity = _serial("valuation_date", valuation_date), _serial("maturity_date", maturity_date)
        if maturity <= reference:
            raise ValueError("maturity_date must follow valuation_date")
        if isinstance(strikes, torch.Tensor) or isinstance(times, torch.Tensor):
            raise TypeError("strikes and times must be fixed sequences, not tensors")
        strikes = tuple(_finite_number("strike", k) for k in strikes)
        if not strikes or min(strikes) <= 0:
            raise ValueError("strikes must be nonempty and positive")
        option_types = tuple(option_types) if option_types is not None else ("call",)*len(strikes)
        if len(option_types) != len(strikes) or any(t not in ("call", "put") for t in option_types):
            raise ValueError("option_types must contain one call/put for every strike")
        times = tuple(_finite_number("times", t) for t in times)
        horizon = (maturity-reference)/365.
        if (not times or times[0] < 0 or any(b <= a for a, b in zip(times, times[1:]))
                or (len(times) > 1 and (times[0] != 0 or times[-1] < horizon))):
            raise ValueError("times must increase and cover [0, horizon]")
        steps, scheme_id, _, _ = _config(time_steps, scheme, "full", "auto")
        risk_dates, risk_dfs = _curve("discount_curve", discount_curve, reference, maturity)
        yield_dates, yield_dfs = _curve("dividend_curve", dividend_curve, reference, maturity)
        rate = _finite_number("rate", rate)
        dividend_yield = _finite_number("dividend_yield", dividend_yield)
        device = torch.device(device)
        if device.type not in ("cpu", "cuda"):
            raise ValueError("LatentBatch requires a CPU or CUDA device")
        device = torch.device('cpu') if device.type == 'cpu' else torch.device(
            'cuda', torch.cuda.current_device() if device.index is None else device.index)
        self._axes = tuple(tuple(a) for a in axes)
        self._times, self._horizon, self._device = times, horizon, device
        self._count = len(strikes)
        self._native = torch.classes.quantlibtorch.LatentBatch(axes, list(times), list(strikes),
            [1 if t == "call" else -1 for t in option_types], reference, maturity, rate, dividend_yield,
            risk_dates, risk_dfs, yield_dates, yield_dfs, steps, scheme_id, str(device))

    @property
    def axes(self):
        return self._axes

    @property
    def times(self):
        return self._times

    @property
    def contracts(self):
        return self._count

    @classmethod
    def from_contracts(cls, contracts, **shared):
        """Build from fd_latent-style fixed keyword dictionaries.

        Missing entries inherit shared values/defaults. Every explicit per-
        contract override except strike/option_type must agree exactly after
        sequence normalization. Incompatible problems raise instead of being
        silently regrouped or modified. Use separate plans for those problems.
        """
        def freeze(value):
            if isinstance(value, torch.Tensor):
                raise TypeError("contract configuration must be fixed, not tensors")
            if isinstance(value, dict):
                return tuple(sorted((k, freeze(v)) for k, v in value.items()))
            if isinstance(value, (list, tuple)):
                return tuple(freeze(v) for v in value)
            return value
        import inspect
        defaults = {k: v.default for k, v in inspect.signature(cls).parameters.items()
                    if v.default is not inspect.Parameter.empty and k not in ("strikes", "option_types")}
        rows = []
        for contract in contracts:
            row = {**defaults, **shared, **dict(contract)}
            if "strike" not in row:
                raise ValueError("each contract requires strike")
            rows.append(row)
        if not rows:
            raise ValueError("contracts must not be empty")
        config = {k: v for k, v in rows[0].items() if k not in ("strike", "option_type")}
        key = freeze(config)
        for row in rows[1:]:
            candidate = {k: v for k, v in row.items() if k not in ("strike", "option_type")}
            if freeze(candidate) != key:
                changed = sorted(k for k in config.keys() | candidate.keys()
                                 if freeze(config.get(k)) != freeze(candidate.get(k)))
                raise ValueError(f"incompatible contract configuration: {', '.join(changed)}")
        return cls([r["strike"] for r in rows], option_types=[r.get("option_type", "call") for r in rows], **config)

    def price(self, latent_drift, diffusion, initial_state, *, mode="adjoint"):
        """Return connected prices [contracts] from shared, graph-connected fields."""
        if mode not in ("full", "adjoint"):
            raise ValueError("mode must be full or adjoint")
        # Native validation owns shape/device/finiteness checks so a large field
        # is not scanned twice at this execution boundary.
        for name, value in (("latent_drift", latent_drift), ("diffusion", diffusion), ("initial_state", initial_state)):
            if not isinstance(value, torch.Tensor):
                raise TypeError(f"{name} must be a torch.Tensor")
        return self._native.price(latent_drift, diffusion, initial_state, mode == "adjoint")


def diffusion_rollback_batch(drift, diffusion, terminal, *, axes, times=None,
                             killing=None, horizon=1., time_steps=30,
                             scheme="hundsdorfer", mode="full"):
    """QuantLib diffusion rollback with shared coefficients and terminal [N,B].

    Each column is an independent RHS. All columns use the exact same fixed
    numerical problem, including boundaries. Spatial/coefficient conventions
    match diffusion_rollback; the original single-RHS implementation remains
    independently available. One to arbitrary spatial dimensions, CPU float64.
    """
    axes = _axes(axes)
    horizon = _finite_number("horizon", horizon)
    if horizon <= 0:
        raise ValueError("horizon must be positive")
    times = _fields(drift, diffusion, times, axes, horizon, False)
    n = math.prod(map(len, axes))
    _tensor("terminal", terminal)
    if terminal.ndim != 2 or terminal.shape[0] != n or terminal.shape[1] < 1:
        raise ValueError("terminal must have shape [nodes, contracts]")
    if killing is None:
        killing = drift.new_zeros(drift.shape[:2])
    _tensor("killing", killing)
    steps, scheme_id, adjoint, _ = _config(time_steps, scheme, mode, "auto")
    return torch.ops.quantlibtorch._packed_diffusion(drift, diffusion, killing, terminal,
        axes, times, horizon, steps, scheme_id, adjoint)
