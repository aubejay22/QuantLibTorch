"""QuantLib/LibTorch CPU pricing and batched CPU/CUDA tensor primitives."""
from .solver import tridiagonal_solve
from .fd import fd_vanilla
from .fd_basket import fd_basket
from .latent import diffusion_rollback, fd_latent, state_grid
from .batch import LatentBatch, diffusion_rollback_batch
from .calibration import OptionQuote, LatentCalibration
from .pricing import european_call, log_moneyness_grid
from .kernels import tridiagonal_apply, band_axpyb, tridiagonal_solve_pcr

__all__ = ["tridiagonal_solve", "european_call", "log_moneyness_grid", "fd_vanilla", "fd_basket",
           "tridiagonal_apply", "band_axpyb", "tridiagonal_solve_pcr",
           "diffusion_rollback", "fd_latent", "state_grid", "OptionQuote", "LatentCalibration",
           "LatentBatch", "diffusion_rollback_batch"]
