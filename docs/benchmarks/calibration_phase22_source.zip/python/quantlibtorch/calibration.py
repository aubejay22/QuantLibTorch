"""Multi-contract objectives over the existing QuantLib latent pricing adapter.

This module schedules scalar prices. It is not a batched PDE solver.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
import math

import torch
from torch.profiler import record_function

from .fd import _integer, _serial
from .latent import _axes, _tensor, fd_latent, state_grid
from .pricing import _finite_number


@dataclass(frozen=True)
class OptionQuote:
    """A European quote with a fixed positive residual scale in price units."""
    strike: float
    maturity: date
    price: float
    scale: float = 1.0
    option_type: str = "call"

    def __post_init__(self):
        for name in ("strike", "price", "scale"):
            value = _finite_number(name, getattr(self, name))
            if value < 0 or (name != "price" and value == 0):
                raise ValueError(f"{name} must be {'nonnegative' if name == 'price' else 'positive'}")
        _serial("maturity", self.maturity)
        if self.option_type not in ("call", "put"):
            raise ValueError("option_type must be call or put")


class LatentCalibration:
    """Fixed-contract calibration objective with shared absolute model time.

    model(times, states) returns drift [T,N,m] and loadings [T,N,1+m,w].
    times is a fixed CPU float64 vector, states is state_grid(axes). All calls
    use times from valuation_date, including shorter maturities; time is never
    rescaled separately for each contract. latent_state() returns the current
    differentiable [m] initial state (e.g. a bounded transform of a Parameter).

    loss() retains a single graph and supports higher derivatives in full mode.
    backward() recomputes fields and the initial state for each contract, adds
    first-order gradients of the identical separable mean squared objective,
    and frees each PDE graph. It accumulates into the caller's parameter .grad
    buffers, just like loss().backward(); callers zero these before an update.
    Coefficients are never detached to create surrogate leaves. The returned
    prices and loss from backward() are detached logging values only.

    Models/state callbacks must be deterministic and free of mutable training
    state (no dropout or updating batch-normalization statistics). Tensor
    batches, stochastic objectives and nonseparable penalties are not handled
    by this streaming method. Add a model penalty once outside backward().
    """
    def __init__(self, quotes, *, axes, times, valuation_date=date(2025, 1, 1),
                 spot=100., rate=.03, dividend_yield=.01, discount_curve=None,
                 dividend_curve=None, steps_per_year=30, minimum_steps=4,
                 scheme="hundsdorfer"):
        self.quotes = tuple(quotes)
        if not self.quotes or not all(isinstance(q, OptionQuote) for q in self.quotes):
            raise ValueError("quotes must be a nonempty sequence of OptionQuote")
        self.axes = _axes(axes, minimum=4)
        if len(self.axes) not in (2, 3):
            raise ValueError("calibration supports one or two latent dimensions")
        self.valuation_date = valuation_date
        reference = _serial("valuation_date", valuation_date)
        if any(_serial("maturity", q.maturity) <= reference for q in self.quotes):
            raise ValueError("every maturity must follow valuation_date")
        self.spot = _finite_number("spot", spot)
        if self.spot <= 0:
            raise ValueError("spot must be positive")
        if isinstance(times, torch.Tensor):
            raise TypeError("times must be fixed numbers")
        self.times = tuple(_finite_number("times", t) for t in times)
        horizon = max((q.maturity-valuation_date).days/365 for q in self.quotes)
        if (not self.times or self.times[0] < 0 or any(b <= a for a, b in zip(self.times, self.times[1:]))
                or (len(self.times) > 1 and (self.times[0] != 0 or self.times[-1] < horizon))):
            raise ValueError("times must increase and cover all maturities")
        self.steps_per_year = _integer("steps_per_year", steps_per_year, 1)
        self.minimum_steps = _integer("minimum_steps", minimum_steps, 1)
        self.market = dict(rate=rate, dividend_yield=dividend_yield,
                           discount_curve=discount_curve, dividend_curve=dividend_curve, scheme=scheme)
        self.states = state_grid(self.axes)
        self.time_tensor = torch.tensor(self.times, dtype=torch.float64)
        self.targets = torch.tensor([q.price for q in self.quotes], dtype=torch.float64)
        self.scales = torch.tensor([q.scale for q in self.quotes], dtype=torch.float64)

    def _fields(self, model):
        with record_function("calibration::network_fields"):
            return model(self.time_tensor, self.states)

    def _initial(self, latent_state):
        latent = _tensor("latent state", latent_state())
        if latent.shape != (len(self.axes)-1,):
            raise ValueError("latent state must have shape [latent dimensions]")
        return torch.cat((latent.new_tensor([math.log(self.spot)]), latent))

    def _price(self, fields, initial, quote, mode):
        steps = max(self.minimum_steps, math.ceil(self.steps_per_year*(quote.maturity-self.valuation_date).days/365))
        with record_function("calibration::contract_price"):
            return fd_latent(*fields, initial, axes=self.axes, times=self.times,
                valuation_date=self.valuation_date, maturity_date=quote.maturity,
                strike=quote.strike, option_type=quote.option_type, time_steps=steps, mode=mode, **self.market)

    def prices(self, model, latent_state, *, mode="adjoint"):
        """Return a connected price vector; fields are evaluated once."""
        fields, initial = self._fields(model), self._initial(latent_state)
        return torch.stack([self._price(fields, initial, q, mode) for q in self.quotes])

    def loss(self, model, latent_state, *, mode="adjoint"):
        prices = self.prices(model, latent_state, mode=mode)
        return ((prices-self.targets)/self.scales).square().mean(), prices

    def backward(self, model, latent_state, *, mode="adjoint", contract_context=None):
        """Accumulate exact first-order objective gradients, one graph at a time.

        contract_context(i) optionally supplies a context manager for bounded
        profiling/diagnostics around a whole contract, including its backward.
        """
        from contextlib import nullcontext
        prices, terms = [], []
        for i, quote in enumerate(self.quotes):
            with contract_context(i) if contract_context else nullcontext():
                fields, initial = self._fields(model), self._initial(latent_state)
                price = self._price(fields, initial, quote, mode)
                term = ((price-self.targets[i])/self.scales[i]).square()/len(self.quotes)
                with record_function("calibration::contract_backward"):
                    term.backward()
                prices.append(price.detach())
                terms.append(term.detach())
                del fields, initial, price, term
        return torch.stack(terms).sum(), torch.stack(prices)
