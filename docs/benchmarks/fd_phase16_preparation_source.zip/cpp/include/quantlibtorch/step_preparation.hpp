#pragma once
#include <ATen/core/Tensor.h>
#include <cstddef>
#include <vector>

namespace quantlibtorch {
// Elementary full-AD preparation only: compact scaled bands and step RHS.
// The caller retains the existing guarded solve and every elimination state.
bool try_step_preparation(const at::Tensor& lower, const at::Tensor& diagonal,
    const at::Tensor& upper, const at::Tensor& state, const std::size_t* left,
    const std::size_t* right, double dt, double theta, int kind,
    std::vector<at::Tensor>& output);
}
